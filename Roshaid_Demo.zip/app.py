import os
import random
import sqlite3
import bcrypt

from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
# from twilio.rest import Client
from dotenv import load_dotenv
from PIL import Image
from flask import abort

# Load Environment Variables
load_dotenv()


# Flask App Setup
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY")

app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB limit

@app.errorhandler(413)
def file_too_large(e):
    flash("Image too large! Max size allowed is 2MB.", "danger")
    return redirect(request.url)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, "database.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "images")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Flask-Mail Configuration
app.config.update(
    MAIL_SERVER=os.getenv("MAIL_SERVER"),
    MAIL_PORT=int(os.getenv("MAIL_PORT")),
    MAIL_USE_TLS=os.getenv("MAIL_USE_TLS") == "True",
    MAIL_USERNAME=os.getenv("MAIL_USERNAME"),
    MAIL_PASSWORD=os.getenv("MAIL_PASSWORD"),
    MAIL_DEFAULT_SENDER=os.getenv("MAIL_USERNAME")
)

mail = Mail(app)

# Twilio Configuration
# twilio_client = Client(
#     os.getenv("TWILIO_ACCOUNT_SID"),
#     os.getenv("TWILIO_AUTH_TOKEN")
# )
# TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")

# Database Helper
def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# Utility Functions
def generate_otp():
    return random.randint(100000, 999999)

def send_email_otp(email, otp):
    msg = Message(
        subject="OTP Verification",
        recipients=[email]
    )
    msg.body = f"Your OTP is {otp}. Do not share it."
    mail.send(msg)

# def send_sms_otp(phone, otp):
#     try:
#         twilio_client.messages.create(
#             body=f"Your OTP is {otp}. Do not share it.",
#             from_=TWILIO_PHONE_NUMBER,
#             to=phone
#         )
#     except Exception as e:
#         print("Twilio SMS Error:", e)

# Routes
@app.route("/")
def index():
    return render_template("welcome.html")

# Register
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        mobile = request.form["mobile_number"]
        password = request.form["password"]
        privilege = request.form["privilege"]
        image = request.files.get("image")

        hashed_password = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt()
        )

        filename = "default.png"
        if image and image.filename:
            filename = secure_filename(image.filename)
            image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)

            img = Image.open(image)
            img = img.convert("RGB")                 # Safety
            img.thumbnail((300, 300))                # Max size 300x300
            img.save(image_path, optimize=True, quality=85)

        email_otp = generate_otp()
#       mobile_otp = generate_otp()

        session["email_otp"] = email_otp
#       session["mobile_otp"] = mobile_otp
        session["user_data"] = {
            "name": name,
            "email": email,
            "mobile": mobile,
            "password": hashed_password,
            "privilege": privilege,
            "image": filename
        }

        send_email_otp(email, email_otp)
#       send_sms_otp(mobile, mobile_otp)

        return redirect(url_for("verify"))

    return render_template("register.html")

# Verify OTP
@app.route("/verify", methods=["GET", "POST"])
def verify():
    if request.method == "POST":
        email_otp_input = int(request.form["email_otp"])
        #mobile_otp_input = int(request.form["mobile_otp"])

        if email_otp_input != session.get("email_otp"):
            flash("Invalid OTP", "danger")
            return redirect(url_for("verify"))
        
        # if mobile_otp_input != session.get("mobile_otp"):
        #     flash("Invalid OTP", "danger")
        #     return redirect(url_for("verify"))

        session["email_verified"] = True
        #session["mobile_verified"] = True
        
        user = session["user_data"]

        conn = get_db_connection()
        conn.execute("""
            INSERT INTO user (name, email, mobile_number, password, privilege, email_verified, mobile_verified, image_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user["name"],
            user["email"],
            user["mobile"],
            user["password"],
            user["privilege"],
            1,
            1,
            user["image"]
        ))
        conn.commit()
        conn.close()

        session.clear()
        flash("Account verified successfully!", "success")
        return redirect(url_for("login"))

    return render_template("verify.html")

# Login
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = get_db_connection()
        user = conn.execute(
            "SELECT * FROM user WHERE email = ? AND email_verified = 1 AND mobile_verified = 1",
            (email,)
        ).fetchone()
        conn.close()

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            session["user_id"] = user["id"]
            return redirect(url_for("home"))

        flash("Invalid credentials or unverified account", "danger")

    return render_template("login.html")

# Home
@app.route("/home")
def home():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    user = conn.execute(
        "SELECT name, privilege, image_path FROM user WHERE id = ?",
        (session["user_id"],)
    ).fetchone()
    conn.close()

    return render_template(
        "home.html",
        name=user["name"],
        privilege=user["privilege"],
        image_url=f"/static/images/{user['image_path']}"
    )

# Logout
@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully", "info")
    return redirect(url_for("login"))

# Run App
if __name__ == "__main__":
    app.run(debug=True)