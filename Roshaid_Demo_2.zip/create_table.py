import sqlite3

# Connect to SQLite database
conn = sqlite3.connect("database.db")

# Create a cursor object
cursor = conn.cursor()

# Create users table
cursor.execute("""
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    mobile_number TEXT NOT NULL,
    password BLOB NOT NULL,
    privilege TEXT DEFAULT 'user',
    email_verified INTEGER DEFAULT 0,
    mobile_verified INTEGER DEFAULT 0,
    image_path TEXT
);
""")

# Create data table
cursor.execute("""
CREATE TABLE IF NOT EXISTS data_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    stored_filename TEXT NOT NULL,
    file_type TEXT,
    uploaded_by INTEGER,
    visibility TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES user(id)
);
""")

# Commit changes and close the connection
conn.commit()
conn.close()

print("Database and table created successfully.")
